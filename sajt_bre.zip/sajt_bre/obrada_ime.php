﻿<?php
	if(isset($_GET['ime']))
	{
		$ime=$_GET['ime'];
		
		$ime=addslashes($ime);
		$id_treninga=$_GET['id_treninga'];
		include("konekcija.inc");
							if($id_treninga==0)
							{
								$upit="SELECT * FROM instruktor WHERE ime_prezime LIKE '%$ime%'";
								$rez=mysql_query($upit) or die(mysql_error());
								if($rez == FALSE)
								{
									die(mysql_error());
								}
								while($r=mysql_fetch_array($rez))
								{
									echo("<div class=\"instruktor\">");
										echo("<h2 class=\"instruktor_naslov\">".$r['ime_prezime']."</h2>");
										echo("<div class=\"instruktor_ispis\">");
											echo("<p class=\"o_njemu\">".$r['o_njemu']."</br></br><b>&nbsp&nbsp&nbsp&nbsp&nbspKontakt:".$r['kontakt']."</b></p>");
										echo("</div>");
										echo("<div class=\"instruktor_slika\"><img src=".$r['slika']." alt=".$r['ime_prezime']." width=\"100%\" height=\"250px\"/></div>");
									echo("</div>");
								}
								mysql_close();
							}
							else
							{
								$upit="SELECT * FROM instruktor i JOIN instruktor_treninzi it ON i.id_instruktora=it.id_instruktora JOIN treninzi t ON t.id_treninga=it.id_treninga WHERE it.id_treninga=".$id_treninga." AND ime_prezime LIKE '%$ime%'";
								$rez=mysql_query($upit) or die(mysql_error());
								if($rez == FALSE)
								{
									die(mysql_error());
								}
								while($r=mysql_fetch_array($rez))
								{
									echo("<div class=\"instruktor\">");
										echo("<h2 class=\"instruktor_naslov\">".$r['ime_prezime']."</h2>");
										echo("<div class=\"instruktor_ispis\">");
											echo("<p class=\"o_njemu\">".$r['o_njemu']."</br></br><b>&nbsp&nbsp&nbsp&nbsp&nbspKontakt:".$r['kontakt']."</b></p>");
										echo("</div>");
										echo("<div class=\"instruktor_slika\"><img src=".$r['slika']." alt=".$r['ime_prezime']." width=\"100%\" height=\"250px\"/></div>");
									echo("</div>");
								}
								mysql_close();
							}
	}
?>