﻿<?php
					if(isset($_GET['id_update_inst']))
					{

						$id_inst=$_GET['id_update_inst'];
						$ime_prezime=$_REQUEST['tbImePrezime'];
						$o_njemu=$_REQUEST['o_njemu'];
						$slika=$_REQUEST['tbSlika'];
						$telefon=$_REQUEST['tbTelefon'];
						$ime_prezime=addslashes($ime_prezime);
						$o_njemu=addslashes($o_njemu);
						include("konekcija.inc");
							
						$upit="UPDATE instruktor SET id_instruktora=$id_inst, ime_prezime='$ime_prezime', o_njemu='$o_njemu', slika='$slika', kontakt='$telefon' WHERE id_instruktora=$id_inst";
						
						mysql_query($upit) or die(mysql_query());
						header("location:admin.php");
						mysql_close();
					}
	?>