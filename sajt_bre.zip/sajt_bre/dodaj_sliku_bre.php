﻿<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" 
"http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html>
<head>
		<title>Sportski, rekreativni i zabavni centar | Teretana BRE</title>
		<meta http-equiv="Content-Type" content="text/html"; charset="UTF-8"> 
		<meta name="author" content="Nikola Mihajlovic"/ >
		<link rel="stylesheet" href="css/admin.css" type="text/css" />
		<link rel="shortcut icon" href="ikone/icon.jpg" type="image/x-icon" />
	
		<link href='http://fonts.googleapis.com/css?family=Droid+Serif' rel='stylesheet' type='text/css'/>
		<link href='http://fonts.googleapis.com/css?family=Ubuntu|Vollkorn' rel='stylesheet' type='text/css'/>
		
		<link rel="stylesheet" href="//code.jquery.com/ui/1.11.4/themes/smoothness/jquery-ui.css">
		
		<script src="//code.jquery.com/jquery-1.10.2.js"></script>
		<script src="//code.jquery.com/ui/1.11.4/jquery-ui.js"></script>
	</head>	
	<body>
			<div id="ispis">
				<h1 id="szc" title="Naslov teretana BRE">RODJENDAONICA<a href="index.php" id="bre"> &nbspBRE</a></h1>
				<p class="malo" title="Sportski zabavni centar">Zabavni, drustveni i rekreativni centar</p>
					
				<?php
					include('ispis.inc');
				?>
			</div>
			<div id="meni">
					<?php
						include('meni_rodj.inc');
					?>
				</div>
		<div id="omotac">
			<div id="sredina">
			<form method="POST" action="<?php print $_SERVER['PHP_SELF'] ?>">
			<h2 class="ispisati">Naziv:</h2></br>
				<input type="text" name="tbNaziv" id="tbNaziv" class="tb"/>
			<h2 class="ispisati">Putanja do slike:</h2></br>
				<input type="text" name="tbSlika" id="tbSlika" class="tb"/>
		
				<input type="submit" name="btnUnesi" value="Unesi"/>
				</form>
				<?php 
					if(isset($_REQUEST['btnUnesi']))
					{
						$naziv=$_REQUEST['tbNaziv'];
						$slika=$_REQUEST['tbSlika'];
						$naziv=addslashes($naziv);

						include("konekcija.inc");
							
						$upit="INSERT INTO galerija_slike VALUES('','".$naziv."','".$slika."')";
						mysql_query($upit);
						mysql_close();
					}
				?>
				
			</div>
			
			<div id="desno">
					<?php
						include("desno_rodj.inc");
					?>
			</div>
			
		</div>
		
		<?php
				include("footer.inc");
		?>
	</body>
</html>