﻿<?php
	$email=$_GET['email'];
	$rand=$_GET['r'];
	
	include("konekcija.inc");
	$upit="UPDATE zakazivanje SET verifikacija='1' WHERE email='$email' AND code='$rand'";
	mysql_query($upit) or die(mysql_error());
	mysql_close();
	echo("Uspesno ste zakazali svoj rodjendan! :)");
?>