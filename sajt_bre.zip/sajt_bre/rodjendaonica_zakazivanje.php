﻿<? session_start(); ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" 
"http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html>
		<title>Rodjendaonica BRE | Zakazivanje</title>
		<meta http-equiv="Content-Type" content="text/html"; charset="UTF-8"> 
	
		<meta name="author" content="Nikola Mihajlovic"/ >
	
		
		
		<link rel="stylesheet" href="css/zakazivanje.css" type="text/css" />

		<link rel="shortcut icon" href="ikone/icon.jpg" type="image/x-icon" />
	
		<link href='http://fonts.googleapis.com/css?family=Droid+Serif' rel='stylesheet' type='text/css'/>
		<link href='http://fonts.googleapis.com/css?family=Ubuntu|Vollkorn' rel='stylesheet' type='text/css'/>
		
		<link rel="stylesheet" href="//code.jquery.com/ui/1.11.4/themes/smoothness/jquery-ui.css">
		
		<script src="//code.jquery.com/jquery-1.10.2.js"></script>
		<script src="//code.jquery.com/ui/1.11.4/jquery-ui.js"></script>
		
		<script type="text/javascript" src="js/mesec_ajax.js"></script>
		<script type="text/javascript" src="provera.js"></script>
	</head>
	
	<body>
			<div id="ispis">
				<h1 id="szc" title="Naslov teretana BRE">RODJENDAONICA<a href="rodjendaonica_bre.php" id="bre"> &nbspBRE</a></h1>
				<p class="malo" title="Sportski zabavni centar">Zabavni, drustveni i rekreativni centar</p>
				
				<?php
					include('ispis.inc');
				?>
				
				
				
			</div>
			<div id="meni">
					<?php
						include('meni_rodj.inc');
					?>
				</div>
		<div id="omotac">
			<div id="sredina">
			
				<div id="naslov"><h1 class="sredina_naslov">Zakazite Vas termin</h1></div>
				<div id="div_forma">
					<form name="forma" id="forma" action="zakazivanje_obrada.php" method="POST">
						
						<h2 class="pise">Upisite Vase ime: </h2>
							<input type="text" id="tbIme" name="tbIme" class="ime_prezime"/>
							
						<h2 class="pise">Upisite Vase prezime: </h2>
							<input type="text" id="tbPrezime" name="tbPrezime" class="ime_prezime"/></br>
							
						<h2 class="pise">Upisite kontakt telefon: </h2>
							<input type="text" id="tbTelefon" name="tbTelefon" class="ime_prezime"/></br>
							
						<h2 class="pise">Upisite Vas email: </h2>
							<input type="text" id="tbEmail" name="tbEmail" class="ime_prezime"/></br>
						
						<select id="ddlGodina" name="ddlGodina" class="ddl">
							<option value="0">Godina</option>
							<option value="2015">2015</option>
							<option value="2016">2016</option>
							<option value="2017">2017</option>
						</select>
						
						<select id="ddlMesec" name="ddlMesec" class="ddl" onchange="mesec(this.value)">
							<option value="0">Mesec</option>
							<?php 
								for($i=0; $i<12; $i++)
								{
									$k=$i+1;
									echo("<option value=".$k.">".$k."</option>");
								}
							?>
						</select>
						
						<select id="ddlDan" name="ddlDan" class="ddl" >
							<option value="0">Dan</option>
						</select>
						
						<select id="ddlVreme" name="ddlVreme" class="ddl">
							<option value="0">Vreme</option>
							<option value="14:00 - 16:30">14:00 - 16:30</option>
							<option value="17:00 - 19:30">17:00 - 19:30</option>
							<option value="20:00 - 22:30">20:00 - 22:30</option>
						</select></br>
						<h2 class="pise">Ukoliko zelite nase posluzenje:</h2>
						
						<input type="checkbox" id="chbKetering" name="chb[]" class="chb"  value="1"/>Nas ketering</br>
						<input type="checkbox" id="chbPiceDeca" name="chb[]" class="chb" value="2" />Pice za decu</br>
						<input type="checkbox" id="chbPiceOdrasli" name="chb[]" class="chb" value="3" />Pice za odrasle</br>
						<input type="checkbox" id="chbNase" name="chb[]" class="chb"  value="4"/>Nabavicemo sami</br>
						
						<h2 class="pise">Ukoliko imate bilo kakvu napomenu, upisite je ovde</h2>
						
						<textarea rows="6" cols="40" id="taNapomena" name="taNapomena" class="napomena">
							
						</textarea></br>
						<input type="button" id="btnUnesi" name="btnUnesi" value="Zakazi" class="btn" onclick="provera()"/>
						<input type="reset" id="btnReset" name="btnReset" value="Obrisi" class="btn"/>
					</form>
				</div>
				
				<div id="prikazi">
					<?php
					if(isset($_GET['zakazano']))
					{
							echo("<p class=\"deblje\">Vas rodjendanski termin mora biti potvrdjen preko vaseg email-a! Ulogujte se na mail kako bi zakazali vas rodjendan :)<p>");
					}
					?>
				</div>
			
			</div>
					<div id="desno">
							
				
				<div class="trizanci1">
						<h2 class="trizanci_naslov" title="Kontakt">Kontakt info</h2><span class="ikonice"><img src="ikone/mala_fon_roza.png" alt="kontakt icon"/></span>
						<p class="deblje"><b>Adresa:</b> </p><p class="manji">Metohijska 25, &nbsp11000 Beograd, &nbspSrbija</p>
						<p  class="deblje"><b>Radno vreme:</b> </p>
								<p class="manji">
								Radnim danima: &nbsp od 10:00 am do 10:00 pm</br>
								Subotom:  &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbspod 12:00 pm do 7:00 pm</p>
						<p  class="deblje"><b>Kontakt: &nbsp&nbsp</b>065/2433-436 </p>

						<p  class="deblje"><b>Email:</b> &nbsp
						<a href="mailto:breteretana@yahoo.com?Subject=Zdravo" >breteretana@yahoo.com</a></p>
						<p  class="deblje"><b>Facebook: &nbsp&nbsp</b><a href="https://www.facebook.com/teretanabre?fref=ts">facebook.com/teretanabre</a> </p>
				</div>
				
				
				<div class="trizanci">
						<h2 class="trizanci_naslov" title="Klub A">Klub A</h2><span class="ikonice"><img src="ikone/tegic_mali_roze.png" alt="kontakt icon"/></span>
						<p class="deblje"><b>Klub A-</b> je jedan od lanaca teretana u koju spada i nasa teretana BRE. Club A je u samom vrhu fitnesa jos od 1995 godine, i svakako je pravi
						izbor ako zelite da Vase telo, u najkracem mogucem roku, dovete u top formu!</p>
						<p class="deblje"><b>Adresa: </b>Trscanska 8 &nbsp (011 3822 442)</p>
						<p class="deblje"><b>Adresa: </b>Mutapova 49 (011 2433 436)</p>
						<p class="deblje"><b>Facebook: </b><a href="https://www.facebook.com/cluba.teretana">facebook.com/cluba.teretana</a></p>
				</div>
				
				<div class="trizanci">
						<h2 class="trizanci_naslov" title="Ninas tim">NINAS fitness tim</h2><span class="p"><img src="ikone/mala_aerobic_roze.jpg" alt="kontakt icon"/></span>
						<p class="deblje"><b>Ninas fitnes tim</b> je najrasprostranjeniji profesionalni tim fitnes instruktora na ovim prostorima. 
						Ako ste izabrali nas, sigurno niste pogresili. Mi vodimo preko 30 vrsta grupnih fitnes programa, imamo 60 grupa sa preko 
						1.500 vezbaca na preko 10 lokacija u Beogradu. Vase je samo da dodjete na onu koja vam je najbliza. :)</p></br>
						<p class="deblje"><b>Web prezentacija: &nbsp&nbsp&nbsp</b><a href="http://www.ninastim.com/">ninastim.com</a></p>
				</div>
				
				
				<div class="trizanci">
						<h2 class="trizanci_naslov" title="Baletksa skola">Anketa</h2>
						<p class="deblje"><b>Ocenite nas sajt :)</b></p></br>
						
								
						
						<form action="rodjendaonica_zakazivanje.php?broj=1" method="POST">
							<?php 
								include("konekcija.inc");
								$upitic="SELECT * FROM anketa";
								$rezic=mysql_query($upitic);
								while($redic=mysql_fetch_array($rezic))
								{
									echo("<input type=\"radio\" name=\"rbAnketa\" id=\"rbAnketa\" value=".$redic['id_anketa']."/>".$redic['naziv']."</br>");
								}
								mysql_close();
							?>
							<input type="submit" name="btnAnketa" id="btnAnketa" value="Posalji"/>
						</form>
			
				
					<?php
										
								if(isset($_REQUEST['btnAnketa']))
								{
									if(isset($_COOKIE['anketa']))
									{
											echo("<p class=\"deblji\"><b>Vec ste glasali :)</b></p>");
									}
									else
									{
										$anketa=$_REQUEST['rbAnketa'];
											$anketa=intval($anketa);
											include("konekcija.inc");
											$upit2="SELECT * FROM anketa WHERE id_anketa=".$anketa;
											$rez2=mysql_query($upit2) or die(mysql_error());
											$r2=mysql_fetch_assoc($rez2) or die(mysql_error());
											$vrednost=$r2['vrednost'];
											$vrednost=intval($vrednost);
											$vrednost2=$vrednost+1;
											
											$query="UPDATE anketa SET vrednost='".$vrednost2."' WHERE id_anketa=".$anketa;
											mysql_query($query) or die(mysql_error());
											setcookie('anketa','hvala',time()+60*60*24*30*3);
											mysql_close();
											
									}	
								}
						?>


							</div> 
					</div>
		</div>
		
		<?php
				include("footer.inc");
		?>
	</body>
</html>