﻿<? session_start(); ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" 
"http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html>
		<title>Teretana BRE | Programi</title>
		<meta http-equiv="Content-Type" content="text/html"; charset="UTF-8"> 
		
		<meta name="keywords" content="Bre, teretana, programi">
		
		<meta name="author" content="Nikola Mihajlovic"/ >
		
		<link rel="stylesheet" href="css/programi.css" type="text/css" />
		<link rel="shortcut icon" href="ikone/icon.jpg" type="image/x-icon" />
	
		<link href='http://fonts.googleapis.com/css?family=Droid+Serif' rel='stylesheet' type='text/css'/>
		<link href='http://fonts.googleapis.com/css?family=Ubuntu|Vollkorn' rel='stylesheet' type='text/css'/>
		
		<link rel="stylesheet" href="//code.jquery.com/ui/1.11.4/themes/smoothness/jquery-ui.css">
		
		<script src="//code.jquery.com/jquery-1.10.2.js"></script>
		<script src="//code.jquery.com/ui/1.11.4/jquery-ui.js"></script>
		<script type="text/javascript" src="js/program.js"></script>

	</head>
	
	<body>
			<div id="ispis">
				<h1 id="szc" title="Naslov teretana BRE">TERETANA<a href="teretana_bre_index.php" id="bre" title="Teretana BRE index link"> &nbspBRE</a></h1>
				<p class="malo">Sportski, zabavni i rekreativni centar</p>
					
				<?php
					include('ispis.inc');
				?>
				
			</div>
			<div id="meni">
					<?php
						include('meni.inc');
					?>
			</div>
			
		<div id="omotac">
			<div id="sredina">
				<h2 class="naslov">Body building</h2>
				<p class="sredina_ispis">Постоје разни табуи о боди билдингу и теретани. Ми смо ти који ће трајно скинути те табуе, а како?

							Једноставно је! Открићемо Вам истину о боди билдингу!

							Почеци боди билдинга сежу у 19. век, када је почело веће занимање за мишићав изглед тела по узору на старе Грке. На тренингу у теретани, изводе се вежбе са теговима и на посебно обликованим справама с циљем стимулисања раста мишићне масе.

							Поред тога што ћете радом са теговима повећати мишићну масу, побољшати општи изглед,  бити здравији, имати више самопоуздања, ојачаћете и Вашу коштану масу која ће Вам и те како добро доћи када будете у годинама или ако сте већ зашли у позније доба.

							У боди билдингу можете најбоље извршити корекцију баш оних делова тела који су Вам проблематични, било да сте професионални спортиста у најбољим годинама, старија особа којој је потребан овај вид рекреације или неко ко тренутно није задовољан својим изгледом и здрављем.

							Ако сте задовољни својим изгледом, а желите још више и боље, најбољи начин за  Вас је дефинитивно рад са  слободним оптерећењима или на справама.

							Погледајмо и тренутне резултате после тренинга бодибилдинга: Ви ћете се моментално осећати боље, имаћете тај посебан осећај ''напумпаности'' који ће вас одмах узети под своје и једва ћете чекати следећи тренинг, Ваше тело ће лучити сератонин или хормон среће како га још називају, 
							једноставно депресија и лоше навике ће сваким тренингом постајати историја Вашег претходног живота....

							За професионалце, боди билдинг је начин живљења ,али то ће и Вама постати ако дозволите вашем телу да вам покаже шта му одговара.......наравно да не треба живети по свим правилима, и да неки тренинг и треба пропустити,појести нешто нездраво, али Ви то у Теретани БРЕ нећете желети,
							 јер код нас боди билдинг прелази границу тренирања,  ми се дружимо на тренинзима, смејемо, вежбамо  и ___________ (баш то што сте сада помислили) сви заједно. Запамтите да смо 
							ту због Вас и Вашег тела...запамтите то,  јер је то разлог због кога ћете имати потребу да долазите и да са собом у оазу здравља доводите пријатеље као и да ћете многе баш на боди билдинг тренингу и стећи.....</br></br>
							</p>
							<h2 class="sredina_ispis"><b>Vasa Teretana BRE!</b></h2>
				
			</div>
		
			
			<div id="desno">
					<?php
						include("programi_desno.inc");
					?>
			</div>
			
		</div>
		
		<?php
				include("footer.inc");
		?>
	</body>
</html>