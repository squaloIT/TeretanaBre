﻿function provera()
{
	var forma=document.getElementById("forma");
	var ime=document.getElementById("tbIme").value;
	var prezime=document.getElementById("tbPrezime").value;
	var telefon=document.getElementById("tbTelefon").value;
	var email=document.getElementById("tbEmail").value;
	var godina=document.getElementById("ddlGodina").value;
	var mesec=document.getElementById("ddlMesec").value;
	var dan=document.getElementById("ddlDan").value;
	var vreme=document.getElementById("ddlVreme").value;
	var napomena=document.getElementById("taNapomena").value;
	var nase_proba=document.getElementById("chbNase");
	var ketering_proba= document.getElementById("chbKetering");
	var pice_deca_proba=document.getElementById("chbPiceDeca");
	var pice_odrasli_proba=document.getElementById("chbPiceOdrasli");
	var ketering="";
	var pice_deca="";
	var pice_odrasli="";
	var nase="";
	
	var bla=false;
	
	var imeTest=/^[A-Z]{1}[a-z]{2,20}$/;
	var prezimeTest=/^[A-Z]{1}[a-z]{2,30}$/;
	var telefonTest=/^[0-9+\-\.\/\(\) ]{6,30}$/;
	var emailTest=/^[\w]+@[\w]+\.[a-z\.\-\_]+$/;
	
	if(!imeTest.test(ime))
	{
		document.getElementById("tbIme").style.border="1px solid red";
		bla=true
		return;
	}
	if(imeTest.test(ime))
	{
		document.getElementById("tbIme").style.border="1px solid #000044";
	}
	if(!prezimeTest.test(prezime))
	{
		document.getElementById("tbPrezime").style.border="1px solid red";
		bla=true;
		return;
	}
	if(prezimeTest.test(prezime))
	{
		document.getElementById("tbPrezime").style.border="1px solid #000044";
	}
	if(!telefonTest.test(telefon))
	{
		document.getElementById("tbTelefon").style.border="1px solid red";
		bla=true;
		return;
	}
	if(telefonTest.test(telefon))
	{
		document.getElementById("tbTelefon").style.border="1px solid #000044";
	}
	if(!emailTest.test(email))
	{
		document.getElementById("tbEmail").style.border="1px solid red";
		bla=true;
		return;
	}
	if(emailTest.test(email))
	{
		document.getElementById("tbEmail").style.border="1px solid #000044";
	}
	if(godina=="0")
	{
		document.getElementById("ddlGodina").style.border="1px solid red";
		bla=true;
		return;
	}
	if(godina!="0")
	{
		document.getElementById("ddlGodina").style.border="1px solid #000044";
	}
	if(mesec=="0")
	{
		document.getElementById("ddlMesec").style.border="1px solid red";
		bla=true;
		return;
	}
	if(mesec!="0")
	{
		document.getElementById("ddlMesec").style.border="1px solid #000044";
	}
	if(dan=="0")
	{
		document.getElementById("ddlDan").style.border="1px solid red";
		bla=true;
		return;
	}
	if(dan!="0")
	{
		document.getElementById("ddlDan").style.border="1px solid #000044";
	}
	if(vreme=="0")
	{
		document.getElementById("ddlVreme").style.border="1px solid red";
		bla=true;
		return;
	}
	if(vreme!="0")
	{
		document.getElementById("ddlVreme").style.border="1px solid #000044";
	}
	if(ketering_proba.checked)
	{
		ketering=1;
	}
	if(pice_deca_proba.checked)
	{
		pice_deca=1;
	}
	if(pice_odrasli_proba.checked)
	{
		pice_odrasli=1;
	}
	if(nase_proba.checked)
	{
		nase=1;
	}
	if(nase==0 && ketering==0 && pice_odrasli==0 && pice_deca==0)
	{

		document.getElementById("prikazi").innerHTML="Izaberite da li zelite svoj ketering i pice, ili nase. Hvala :)";
		bla=true;
		return;
	}
	if((nase==1 && ketering==1) || (nase==1 && pice_odrasli==1) || (nase==1 && pice_deca==1) || (nase==1 && ketering==1 && pice_odrasli==1) || (nase==1 && ketering==1 && pice_deca==1) || (nase==1 && pice_odrasli==1 && pice_deca==1) || (nase==1 && ketering==1 && pice_odrasli==1 && pice_deca==1))
	{
		document.getElementById("prikazi").innerHTML="Izaberite da li zelite svoj ketering i pice, ili nase. Hvala :)";
		bla=true;
		return;
	}
	if(bla)
	{
		return;
	}
	
	if(!bla)
	{
			
			forma.action="zakazivanje_obrada.php?btnPrijavi=1"
			forma.submit();
	}
}