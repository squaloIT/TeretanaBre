﻿<?php 
	if(isset($_GET['id_instruktora']))
	{
		$id=$_GET['id_instruktora'];
		include("konekcija.inc");
		$upit="DELETE FROM instruktor WHERE id_instruktora=".$id;
		mysql_query($upit,$konekcija);
		mysql_close();
		header("location:admin.php");
	}
	if(isset($_GET['id_zakazivanja']))
	{
		$id=$_GET['id_zakazivanja'];
		include("konekcija.inc");
		$upit="DELETE FROM zakazivanje WHERE id_zakazivanja=".$id;
		mysql_query($upit);
		mysql_close();
		header("location:admin.php");
	}
	if(isset($_GET['id_slike']))
	{
		$id=$_GET['id_slike'];
		include("konekcija.inc");
		$upit="DELETE FROM galerija_slike WHERE id_slike=".$id;
		mysql_query($upit);
		mysql_close();
		header("location:admin.php");
	}
	if(isset($_GET['id_rodj_slike']))
	{
		$id=$_GET['id_rodj_slike'];
		include("konekcija.inc");
		$upit="DELETE FROM rodj_galerija WHERE id_slike=".$id;
		mysql_query($upit);
		mysql_close();
		header("location:admin.php");
	}
?>