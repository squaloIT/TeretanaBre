﻿<? session_start(); ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" 
"http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html>
<head>
		<title>Zabavni, sportski i rekreativni centar | Rodjendaonica BRE</title>
		<meta http-equiv="Content-Type" content="text/html"; charset="UTF-8"> 
		<meta name="description" content="Dobrodosli u sportski, zabavni i drustveni centar BRE. Rodjendaonica BRE Vama i Vasim malisanima nudi nezaboravne rodjendane i proslave po najpovoljnijim cenama!
		Nas animatorski tim osigurava fantasticnu zabavu za najmladje, kao i za odrasle :)">
		<meta name="keywords" content="Bre, rodjendaonica, rodjendan">
		<meta name="author" content="Nikola Mihajlovic"/ >
		<meta property="og:title" content="Zabavni centar | Rodjendaonica BRE" />
        <meta property="og:type" content="article" />
        <meta property="og:url" content="index.php" />
        <meta property="og:image" content="gym/teretana_bre_logo.jpg" />
        <meta property="og:site_name" content="TeretanaBRE.rs" />
        <meta property="og:description" content="Dobrodosli u sportski, zabavni i drustveni centar BRE. Rodjendaonica BRE Vama i Vasim malisanima nudi nezaboravne rodjendane i proslave po najpovoljnijim cenama!
		Nas animatorski tim osigurava fantasticnu zabavu za najmladje, kao i za odrasle :)." />
		
		
		<link rel="stylesheet" href="css/rodjendaonica.css" type="text/css" />
		<link rel="shortcut icon" href="ikone/icon.jpg" type="image/x-icon" />
	
		<link href='http://fonts.googleapis.com/css?family=Droid+Serif' rel='stylesheet' type='text/css'/>
		<link href='http://fonts.googleapis.com/css?family=Ubuntu|Vollkorn' rel='stylesheet' type='text/css'/>
		
		<link rel="stylesheet" href="//code.jquery.com/ui/1.11.4/themes/smoothness/jquery-ui.css">
		
		<script src="//code.jquery.com/jquery-1.10.2.js"></script>
		<script src="//code.jquery.com/ui/1.11.4/jquery-ui.js"></script>
		

	</head>
	
	<body>
			<div id="ispis">
				<h1 id="szc" title="Naslov teretana BRE">RODJENDAONICA<a href="rodjendaonica_bre.php" id="bre"> &nbspBRE</a></h1>
				<p class="malo" title="Sportski zabavni centar">Zabavni, drustveni i rekreativni centar</p>
					
				<?php
					include('ispis.inc');
				?>
				
				
				
			</div>
			<div id="meni">
					<?php
						include('meni_rodj.inc');
					?>
				</div>
		<div id="omotac">
			<div id="sredina">
			
				<div id="slika_omot">
					<img src="rodjen/kidsparty.jpg" width="732px" height="400px"  alt="Fitness_slika" align="right"/>
				</div>
				
				<div id="ispod_slike">
						<h2 class="welcome" title="Sportski zabavni centar">Rodjendaonica BRE Vama i Vasim malisanima nudi!</h2>
							<p class="ispod_slike_ispis"><b>Рођендаоница БРЕ</b> Вам нуди нов простор у којем ће се Ваша деца одлично забављати, а Ви ћете уживати у комфорности.
							Цео простор је климатизован и специјално опремљен за безбедну забаву Ваше деце. Наша рођендаоница је затвореног типа, што значи да ћете у току Вашег славља 
							Ви са Вашим гостима имати на располагању цео простор само за Вас, као и да ће цео тим Рођендаонице Бре бити посвећен само Вама и реализацији прославе у потпуности
							по Вашим жељама.</br></br><b>Омиљени део </b>нашим најмлађим рођенданцима и њиховој дружини, до 7 година, свакако јесте дечији кутак специјално опремљен управо за њих. 
							У дечијем кутку они уживају у забавном лавиринту који се простире на три нивоа
							и садржи низ препрека које они са осмехом савладавају, тобоган, меки тунел, меке ваљке, висећи мост, љуљашке, трамболину и неке скривене делове у којима 
							се јављају прве симпатије... </br></br>
							<b>Поред лавиринта</b>, постоји и посебан беби базен са лоптицама за оне најмлађе којима су препреке у лавиринту још увек претешке. За оне мало смелије и наше 
							младе авантуристе обезбедили смо супер Спајдермен стену за пењање у чијем савладавању Ваши најмлађи имају помоћ наших девојака, које су све време 
							са малишанима у дечијем кутку.</br></br>
							<b>Централни, главни део рођендаонице</b> обожавају они мало старији који су прерасли дечији кутак. Најпространији део рођендаонице направљен је тако да задовољи
							све њихове потребе. Ту их очекује и комплетно намештен део за уживање у храни, сокићима и наравно рођенданској торти. После тортице, простор добија сасвим
							другу димензију и прераста
							у прави диско клубић са диско куглом, light show-ом и музиком прилагођеном узрасту и жељи детета. За такмичарски расположене рођенданце ту је и Nintendo 
							Wii са великим бројем игара.</br></br>
							<b>Посебну чаролију нашем простору</b>, који је предвиђен за око 35-оро деце, и Вашој прослави даје професионални аниматорски тим рођендаонице БРЕ чија је 
							анимација толико забавна да се поред деце, која са одушевљењем учествују у њој, често прикључују и родитељи који не могу да јој одоле.</br></br>
							О сваком детаљу је вођено рачуна, а све у намери да се наши рођенданци и њихови гости осећају најлепше и најважније. 
							Свакако смо водили рачуна и о Великим гостима, који у нашем кафићу проводе пријатне сате у опуштеној атмосфери уз ћаскање и послужење.</br></br></p>
							<b class="podebljano">Ваше је само да дођете, а остало препустите нама! :)</b>
							
				
				</div>
			</div>
			
			<div id="desno">
					<?php
						include("desno_rodj.inc");
					?>
			</div>
			
		</div>
		
		<?php
				include("footer.inc");
		?>
	</body>
</html>