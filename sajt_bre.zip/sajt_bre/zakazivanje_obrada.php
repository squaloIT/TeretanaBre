﻿<?php 
if(isset($_GET['btnPrijavi']))
{
	$ime=$_POST['tbIme'];
	$prezime=$_REQUEST['tbPrezime'];
	$telefon=$_REQUEST['tbTelefon'];
	$email=$_REQUEST['tbEmail'];
	$godina=$_REQUEST['ddlGodina'];
	$mesec=$_REQUEST['ddlMesec'];
	$dan=$_REQUEST['ddlDan'];
	$vreme=$_REQUEST['ddlVreme'];
	$chb=$_REQUEST['chb'];
	$napomena=$_REQUEST['taNapomena'];
	$r=rand(0,20000);
	
	$ketering=false;
	$pice_deca=false;
	$pice_odrasli=false;
	
	$imeTest="/^[A-Z]{1}[a-z]{2,20}$/";
	$prezimeTest="/^[A-Z]{1}[a-z]{2,30}$/";
	$telefonTest="/^[0-9+\-\.\/\(\) ]{6,30}$/";
	$emailTest="/^[\w]+@[\w]+\.[a-z\.\-\_]+$/";
	
	$bla=true;
	
	if(!preg_match($imeTest,$ime))
	{
		$bla=false;
	}
	if(!preg_match($prezimeTest,$prezime))
	{
		$bla=false;
	}
	if(!preg_match($telefonTest,$telefon))
	{
		$bla=false;
	}
	if(!preg_match($emailTest,$email))
	{
		$bla=false;
	}
	if($godina=="0")
	{
		$bla=false;
	}
	if($mesec=="0")
	{
		$bla=false;
	}
	if($dan=="0")
	{
		$bla=false;
	}
	if($vreme=="0")
	{
		$bla=false;
	}


		$rez=implode(" ",$chb);
	if($rez=="1")
	{
		$ketering=1;
		$pice_deca=0;
		$pice_odrasli=0;
	}
	if($rez=="2")
	{
		$pice_odrasli=1;
		$pice_deca=0;
		$ketering=0;
	}
	if($rez=="2")
	{
		$pice_deca=1;
		$pice_odrasli=0;
		$ketering=0;
	}
	if($rez=="1 3")
	{
		$ketering=1;
		$pice_odrasli=1;
		$pice_deca=0;
	}
	if($rez=="1 2")
	{
		$ketering=1;
		$pice_deca=1;
		$pice_odrasli=0;
	}
	if($rez=="2 3")
	{
		$pice_deca=1;
		$pice_odrasli=1;
		$ketering=0;
	}
	if($rez=="1 2 3")
	{
		$ketering=1;
		$pice_deca=1;
		$pice_odrasli=1;
	}
	if($rez=="4")
	{
		$ketering=0;
		$pice_deca=0;
		$pice_odrasli=0;
	}
	if($bla==false)
	{
		echo "asdas";
	}
	if($bla==true)
	{
			include("konekcija.inc");	
			$upit="INSERT INTO zakazivanje (ime,prezime,telefon,email,godina,mesec,dan,vreme,ketering,pice_deca,pice_odrasli,napomena,verifikacija,code) 
			VALUES ('".$ime."','".$prezime."','".$telefon."','".$email."','".$godina."','".$mesec."','".$dan."','".$vreme."','".$ketering."','".$pice_deca."','".$pice_odrasli."','".$napomena."','','".$r."')";
			mysql_query($upit) or die(mysql_error());
			
			mail($email,'Verifikacija rodjendana','Postovani '.$ime.', kliknite na link ispod kako bi verifikovali Vas rodjendan. Srdacan pozdrav, rodjendaonica BRE. http://nikola26.net84.net/verifikacija.php?email='.$email.'&r='.$r);
			mysql_close();
			header("location:rodjendaonica_zakazivanje.php?zakazano=12");
			
		
	}
}
?>