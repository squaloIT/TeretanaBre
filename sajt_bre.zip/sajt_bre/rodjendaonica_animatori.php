﻿<? session_start(); ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" 
"http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html>
<head>
		<title>Rodjendaonica BRE | Animatori</title>
		<meta http-equiv="Content-Type" content="text/html"; charset="UTF-8"> 
		
		<meta name="keywords" content="Bre,rodjendaonica, animatori">
		<meta name="author" content="Nikola Mihajlovic"/ >

		
		
		<link rel="stylesheet" href="css/animatori.css" type="text/css" />
		<link rel="shortcut icon" href="ikone/icon.jpg" type="image/x-icon" />
	
		<link href='http://fonts.googleapis.com/css?family=Droid+Serif' rel='stylesheet' type='text/css'/>
		<link href='http://fonts.googleapis.com/css?family=Ubuntu|Vollkorn' rel='stylesheet' type='text/css'/>
		
		<link rel="stylesheet" href="//code.jquery.com/ui/1.11.4/themes/smoothness/jquery-ui.css">
		
		<script src="//code.jquery.com/jquery-1.10.2.js"></script>
		<script src="//code.jquery.com/ui/1.11.4/jquery-ui.js"></script>
		

	</head>
	
	<body>
			<div id="ispis">
				<h1 id="szc" title="Naslov teretana BRE">RODJENDAONICA<a href="rodjendaonica_bre.php" id="bre"> &nbspBRE</a></h1>
				<p class="malo" title="Sportski zabavni centar">Zabavni, drustveni i rekreativni centar</p>
					
				<?php
					include('ispis.inc');
				?>
				
				
				
			</div>
			<div id="meni">
					<?php
						include('meni_rodj.inc');
					?>
				</div>
		<div id="omotac">
		
			<div id="sredina">
			
				<div id="slika_omot">
					<img src="rodjen/animatori2.jpg" id="slika" width="732px" height="300px"  alt="Fitness_slika" align="left"/>
				</div>
				
				<div id="ispod_slike">
						<h2 class="welcome" title="Sportski zabavni centar">Animatorski tim Rodjendaonice BRE</h2>
							<p class="ispod_slike_ispis"><b>Аниматорски Тим Бре!</b> чине девојке квалификоване за рад са децом. Код нас ниједан рођендан није исти. За сваки рођендан анимација се посебно
							прилагођава узрасту и жељи рођенданаца и њиховој дружини, како би за време и по завршетку рођендана они били срећни и задовољни, јер то је једино битно, зар не? :)
							по Вашим жељама.</br></br><b>Ток рођендана са анимацијом Тима Бре! подељен је на три дела: </b>
							</br></br>
							<b>Први део,</b> док нам гости још пристижу, осмишљен је и испуњен играма  које су прилагођене тако да свако дете које стигне на рођендан у сваком 
							тренутку може да се прикључи игри, а да при томе не прекида већ започету забаву осталим другарима..</br></br>
							<b>Други део рођендана</b>  састављен је од такмичарских игара - праве се екипе, смишљају имена,

							навија се и прави права такмичарска атмосфера којој се врло често
							прикључе и маме и тате. У рођендаоници влада прави такмичарски дух. 
							Поред специјално осмишљених игара, правимо и надметање у разним спортовима на Nintendo wii-u.
							у прави диско клубић са диско куглом, light show-ом и музиком прилагођеном узрасту и жељи детета. За такмичарски расположене рођенданце ту је и Nintendo 
							Wii са великим бројем игара.</br></br>
							<b>Трећи и последњи,</b> део претвара рођендан у најбољу журку, а рођендаоницу
							у праву правцату дискотеку. Забављамо се сви, неретко нам се прикључују и родитељи, играмо, учимо нове кораке, откривамо праве плесаче и проводимо се незаборавно.</br></br>
							Ако имамо више спортски него плесачки настројено друштво, увек смо  расположени да,
							по договору са родитељима, тај последњи део рођендана проведемо у Теретани, на тракама, бициклима, степерима и тако направимо прави спортски рођендан.</br></br>
							У случају да другари (понекад и родитељи J) на рођендану пожеле да на тренутак постану неко други,

							 <b>Аниматорски Тим Бре</b> нуди и одличан face painting (сликање лицa) и  за тренутак Ваше клинце и клинцезе претвара у праве Спајдермене, Бетмене,
							 Далматинце, кловнове, Hello Kitty, принцезице и у све друго што они пожеле.</p>
						
							
				
				</div>
			</div>
			
			<div id="desno">
					<?php
						include("desno_rodj.inc");
					?>
			</div>
			
		</div>
		
		<?php
				include("footer.inc");
		?>
	</body>
</html>