﻿<? session_start(); ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" 
"http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html>
		<title>Rodjendaonica BRE | Cenovnik</title>
		<meta http-equiv="Content-Type" content="text/html"; charset="UTF-8"> 
		
		<meta name="keywords" content="Bre, rodjendaonica, cenovnik">
		<meta name="author" content="Nikola Mihajlovic"/ >

		
		
		<link rel="stylesheet" href="css/cenovnik.css" type="text/css" />
		<link rel="shortcut icon" href="ikone/icon.jpg" type="image/x-icon" />
	
		<link href='http://fonts.googleapis.com/css?family=Droid+Serif' rel='stylesheet' type='text/css'/>
		<link href='http://fonts.googleapis.com/css?family=Ubuntu|Vollkorn' rel='stylesheet' type='text/css'/>
		
		<link rel="stylesheet" href="//code.jquery.com/ui/1.11.4/themes/smoothness/jquery-ui.css">
		
		<script src="//code.jquery.com/jquery-1.10.2.js"></script>
		<script src="//code.jquery.com/ui/1.11.4/jquery-ui.js"></script>
		

	</head>
	
	<body>
			<div id="ispis">
				<h1 id="szc" title="Naslov teretana BRE">RODJENDAONICA<a href="rodjendaonica_bre.php" id="bre"> &nbspBRE</a></h1>
				<p class="malo" title="Sportski zabavni centar">Zabavni, drustveni i rekreativni centar</p>
					
				<?php
					include('ispis.inc');
				?>
				
				
				
			</div>
			<div id="meni">
					<?php
						include('meni_rodj.inc');
					?>
				</div>
		<div id="omotac">
			<div id="sredina">
			
				
				<div id="ispod_slike">
						<h2 class="welcome" title="Rodjendaonica BRE">Rodjendaonica BRE Cenovnik!</h2>
							<p class="ispod_slike_ispis"><b>
							Закуп рођендаонице</b> на 2.5 ч је <b>6500,00 дин.</b> Цена закупа играонице укључује коришћење лавиринта, вештачке стене за пењање,
							беби базена са лоптицама и разне играчке за млађу децу, диско клубића за млађу, односно дискотеке за старију децу, 
							тинејџере, Nintendo Wii..., комплетно украшен цео простор, прибор за јело и пиће за децу и одрасле (шоље, чаше, тањире, овале oд акропала, 
							есцaјг, салвете, итд.), позивнице за рођендан.</br></br>
							<b>Безалкохолно пиће </b>је са нашег шанка. Знајући да родитељи често имају проблем са рачунима пића  на крају рођендана, имамо потребу да нагласимо да се код нас то неће десити. Цене кафа и свих безакохолних пића код нас су најниже у граду у шта ћете се и сами уверити. Ви и
							Ваши гости нећете уопште бринути о томе колико сте попили, а на крају рођендана нећете доживети непријатно изненађење које би Вам покварило утисак целог рођендана. </br></br>
							<b>У нашој понуди имамо</b> и велики избор алкохолног пића, такође по најнижим ценама у граду, али ако то Вама више одговара, можете донети Ваше.</br></br>
							<b>Што се тиче хране и торте</b>, можете донети Ви у својој режији, или све можете наручити из наше богате понуде по набавним ценама. (5000 dinara je nas ketering, pice za odrasle i decu)</br></br>
							</p>
							<b class="podebljano">Прави договор рођендан прави! :)</b>
							
				
				</div>
			</div>
			
			<div id="desno">
					<?php
						include("desno_cenovnik.inc");
					?>
			</div>
			
		</div>
		
		<?php
				include("footer.inc");
		?>
	</body>
</html>