﻿<? session_start(); ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" 
"http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html>
<head>
		<title>Teretana BRE | Autor</title>
		<meta http-equiv="Content-Type" content="text/html"; charset="UTF-8"> 
	
		
		
		<link rel="stylesheet" href="css/pocetna.css" type="text/css" />

		<link rel="shortcut icon" href="ikone/icon.jpg" type="image/x-icon" />
	
		<link href='http://fonts.googleapis.com/css?family=Droid+Serif' rel='stylesheet' type='text/css'/>
		<link href='http://fonts.googleapis.com/css?family=Ubuntu|Vollkorn' rel='stylesheet' type='text/css'/>
		
		<link rel="stylesheet" href="//code.jquery.com/ui/1.11.4/themes/smoothness/jquery-ui.css">
		
		<script src="//code.jquery.com/jquery-1.10.2.js"></script>
		<script src="//code.jquery.com/ui/1.11.4/jquery-ui.js"></script>
		
	</head>
	
	<body>
			<div id="ispis">
				<h1 id="szc" title="Naslov teretana BRE">TERETANA<a href="teretana_bre_index.php" id="bre"> &nbspBRE</a></h1>
				<p class="malo" title="Sportski zabavni centar">Sportski, zabavni i rekreativni centar</p>
					
				<?php
					include('ispis.inc');
				?>
			</div>
			<div id="meni">
					<?php
						include('meni.inc');
					?>
				</div>
		<div id="omotac">
			<div id="sredina">
			
				<div id="ispisic">
				<h3 class="autoric">Zdravo!</h3>
				<p class="autor_ispis">Moje ime je Nikola Mihajlovic i imam 20 godina. Imam zavrsenu Osnovnu, kao i Srednju Elektrotehnicku skolu "Nikola Tesla" u Beogradu. Imam zavrsen srednji kurs engleskog jezika u skoli ST. NICOLAS. 
				Trenutno studiram na Visokoj ICT skoli na smeru IT. Tendencija mi je bavljenje programiranjem, i za sebe takodje mislim da imam dar za dizajniranje web strana.
				Volim rad u timu, kao i konkurenciju jer me tera da budem bolji.</br>
				<b>Kontakt: </b>066/91-61-105</br></br>
				<b>Email: </b>nikola.mihajlovic.26.13@ict.edu.rs</p>
				</div>
					<div id="slika_omot">
					<img src="gym/ja.jpg" alt="Fitness_slika" align="right"/>
				</div>
				
				<div id="ispod_slike">
					
							
							
							
				</div>
			</div>
			
			<div id="desno">
					<?php
						include("desno.inc");
					?>
			</div>
			
		</div>
		
		<?php
				include("footer.inc");
		?>
	</body>
</html>