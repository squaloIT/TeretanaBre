﻿<? session_start(); ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" 
"http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html>
<head>
		<title>Sportski, rekreativni i zabavni centar | Teretana BRE</title>
		<meta http-equiv="Content-Type" content="text/html"; charset="UTF-8"> 
		<meta name="description" content="Dobrodosli u sportski, zabavni i drustveni centar BRE. Teretana BRE je vec godinaama u samom vrhu Beogradskog fitnesa. Pored fitnes centra, tu je i rodjendaonica BRE 
		gde mozete organizovati najbolje rodjendanske proslave za najmladje.">
		<meta name="keywords" content="Bre, teretana, fitness, kardio, ninas, trening">
		<meta name="author" content="Nikola Mihajlovic"/ >
		<meta property="og:title" content="Sportski, rekreativni i zabavni centar | Teretana BRE" />
        <meta property="og:type" content="article" />
        <meta property="og:url" content="index.php" />
        <meta property="og:image" content="gym/teretana_bre_logo.jpg" />
        <meta property="og:site_name" content="TeretanaBRE.rs" />
        <meta property="og:description" content="Dobrodosli u sportski, zabavni i drustveni centar BRE. Teretana BRE je vec godinaama u samom vrhu Beogradskog fitnesa. Pored fitnes centra, tu je i rodjendaonica BRE 
		gde mozete organizovati najbolje rodjendanske proslave za najmladje." />
		
		
		<link rel="stylesheet" href="css/pocetna.css" type="text/css" />
		<link rel="stylesheet" href="css/accordion.css" type="text/css"/>
		<link rel="shortcut icon" href="ikone/icon.jpg" type="image/x-icon" />
	
		<link href='http://fonts.googleapis.com/css?family=Droid+Serif' rel='stylesheet' type='text/css'/>
		<link href='http://fonts.googleapis.com/css?family=Ubuntu|Vollkorn' rel='stylesheet' type='text/css'/>
		
		<link rel="stylesheet" href="//code.jquery.com/ui/1.11.4/themes/smoothness/jquery-ui.css">
		
		<script src="//code.jquery.com/jquery-1.10.2.js"></script>
		<script src="//code.jquery.com/ui/1.11.4/jquery-ui.js"></script>
		
		<script type="text/javascript" src="js/accordion.js"></script>
		<script type="text/javascript" src="js/slider.js"></script>
	</head>
	
	<body onLoad="Slider();">
			<div id="ispis">
				<h1 id="szc" title="Naslov teretana BRE">TERETANA<a href="teretana_bre_index.php" id="bre"> &nbspBRE</a></h1>
				<p class="malo" title="Sportski zabavni centar">Sportski, zabavni i rekreativni centar</p>
					
				<?php
					include('ispis.inc');
				?>
			</div>
			<div id="meni">
					<?php
						include('meni.inc');
					?>
				</div>
		<div id="omotac">
			<div id="sredina">
			
				<div id="slika_omot">
					<img src="gym/prava.jpg" alt="Fitness_slika" align="right"/>
				</div>
				
				<div id="ispod_slike">
						<h2 class="welcome" title="Sportski zabavni centar">Sportski, zabavni i drustveni centar BRE Vam nudi!</h2>
							
							<div class="accordion">
								
								<div class="accordion-section">
									<a class="accordion-section-title" href="#accordion-1" title="link teretana bre"><b>Teretana BRE</b></a><span class="pomeri"> <img src="ikone/ikona.png" alt="tegic" /></span>
									 
									<div id="accordion-1" class="accordion-section-content">
										<p title="O teretani bre"  class="accordion_text">Cao, mi smo Teretana BRE! Sportsko rekreativni zabavni centar!

											Nastali smo sa ciljem da promovisemo rekreaciju i fitnes, kao i zdrav 

											nacin zivota. Sve usluge kod nas Bilo da su grupni,individualni ili 

											samostalni trenizni, pruzice Vam strucno osoblje sa sportske akademije 

											 i Difa. Uz ekstra povoljne cene, higijenu, kvalitet opreeme, grupnog 

											i individualnog rada sa clanovima pocnite Vas bolji zivot u Teretani 

											BRE. Pored profesionalnog bodi bilding programa (sprave i slobodna 

											opterecenja), posedujemo i kardio program vodecih svetskih 

											proizvodjaca, veliku salu za grupne treninge, tuseve,i zelju da Vam 

											budemo lepsa strana zivota.</br></p>
									</div><!--end .accordion-section-content-->

								</div><!--end .accordion-section-->
								
								<div class="accordion-section">
									<a class="accordion-section-title" href="#accordion-2" title="link rodjendaonica bre"><b>Rodjendaonica BRE</b></a><span class="pomeri"> <img src="ikone/62433-200.png" alt="tegic" /></span>
									 
									<div id="accordion-2" class="accordion-section-content">
										<p title="O rodjendaonici bre" class="accordion_text">Rodjendaonica BRE se nalazi u sklopu Teretane BRE. Tu smo da Vasem slavljeniku/ci pruzimo nezaboravno slavlje uz brojne drustvene i zabavne igre.
										Za zabavu najmladjih su zaduzeni animatori nase rodjendaonice, koji su tu da brinu i animiraju Vase najmilije tokom celog rodjendana. O posluzenju, keteringu i grickalicama ne morate
										brinuti jer iste mozete naruciti direktno kod nas! </br>
										</p>
									</div><!--end .accordion-section-content-->

								</div><!--end .accordion-section-->
								
								<div class="accordion-section">
									<a class="accordion-section-title" href="#accordion-3" title="link caffe bre"><b>BRE Caffe</b></a><span class="pomeri"> <img src="ikone/martini2.png" alt="tegic" /></span>
									 
									<div id="accordion-3" class="accordion-section-content">
										<p title="O Bre caffe-u"  class="accordion_text">Bre Caffe je takodje u sklopu Teretane BRE. U nasem malom kutku za opustanje, u lepoj i prijatnoj atmosferi mozete sacekati svoje dete, popiti pice posle napornog treninga ili
										doci na jutarnju kafu. Cene su vise nego pristupacne, osoblje ljubazno i spremno da ispuni sve Vase zahteve. </br></p>
									</div><!--end .accordion-section-content-->

								</div><!--end .accordion-section-->
							
							</div><!--end .accordion-->
							
							<div id="slider">
								<div class="slider_section">
									<img class="1" src="gym/slajder11.jpg" alt="teretana bre slika1" title="slajder BRE"/>
									<img class="2" src="rodjen/slajder77.jpg" alt="rodjendaonica bre 1" title="slajder BRE"/>
									<img class="3" src="rodjen/slajder1010.jpg" alt="rodjendaonica bre 4" title="slajder BRE"/>
								</div>
								
								<div class="slider_section">
									<img class="1" src="gym/slajder22.jpg" alt="teretana bre slika2"  title="slajder BRE"/>
									<img class="2" src="rodjen/slajder1111.jpg" alt="rodjendaonica bre 5"  title="slajder BRE"/>
									<img class="3" src="rodjen/slajder1212.jpg" alt="rodjendaonica bre 6"  title="slajder BRE"/>
								</div>
								
								<div class="slider_section">
									<img class="1" src="gym/slajder33.jpg" alt="teretana bre slika3"  title="slajder BRE"/>
									<img class="2" src="rodjen/slajder88.jpg" alt="rodjendaonica bre 2"  title="slajder BRE" />
									<img class="3" src="rodjen/slajder99.jpg" alt="rodjendaonica bre 3" title="slajder BRE"/>
									
								</div>
							</div>
				</div>
			</div>
			
			<div id="desno">
					<?php
						include("desno.inc");
					?>
			</div>
			
		</div>
		
		<?php
				include("footer.inc");
		?>
	</body>
</html>