﻿function Slider()
{
	$("#slider > .slider_section > .1").show("fade",500);
	$("#slider > .slider_section > .1").delay(5500).hide("slide",{direction: "left"},500);
	var sc =$(".slider_section img").size()/3;
	var count=2;

	
	setInterval(function()
	{
		$(".slider_section ."+count).show("slide",{direction:"right"},500);
		$(".slider_section ."+count).delay(5500).hide("slide",{direction:"left"},500);
		
		if(count==sc)
		{
			count=1;
		}else{
			count=count+1;
		}
	},6500);
}