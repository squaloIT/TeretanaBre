﻿function kreiranje()
{
	var kanal=false;
	try
	{
		kanal=new XMLHttpRequest();
		return kanal;
		alert(kanal);
	}
	catch(trymicrosoft)
	{
		try
		{
			kanal = new ActiveXObject("Msmx12.XMLHttp");
			return kanal;
		}
		catch(othermicrosoft)
		{
			try 
			{
				kanal = new ActiveXObject("Microsoft.XMLHttp"); 
				return kanal;
			}
			catch(failed)
			{
				kanal=false;
			}  
		}
	}
	if(!kanal)
	{
		alert("Kanal nije napravljem, izvinjamo se!! Vasa Teretana BRE!");
	}
}
function ime()
{
	var ime=document.getElementById("tbIme").value;
	var id_treninga=document.getElementById("ddlTreninzi").value;
	kanal=kreiranje();
	if(!kanal)
	{
		alert("Kanal nije napravljem, izvinjamo se!! Vasa Teretana BRE!");
	}
	else
	{
		kanal.onreadystatechange=pokreni;
		kanal.open('GET','obrada_ime.php?ime='+ime+'&id_treninga='+id_treninga,'true');
		kanal.send();
	}
}
function pokreni()
{

	if(kanal.ReadyState==0)
	{
		alert("0");
	}
	else if(kanal.ReadyState==1)
	{
		alert("1");
	}
	else if(kanal.ReadyState==2)
	{
		alert("2");
	}
	else if(kanal.ReadyState==3)
	{
		alert("3");
	}
	else
	{	
		document.getElementById("sredina").innerHTML=kanal.responseText;
	}

}