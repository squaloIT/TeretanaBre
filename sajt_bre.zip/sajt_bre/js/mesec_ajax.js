﻿function kreiranje()
{
	var kanal=false;

	try
	{
		
		kanal=new XMLHttpRequest();
		return kanal;
		
	}
	catch(trymicrosoft)
	{
		try
		{
			kanal = new ActiveXObject("Msmx12.XMLHttp");
			return kanal;
		}
		catch(othermicrosoft)
		{
			try 
			{
				kanal = new ActiveXObject("Microsoft.XMLHttp"); 
				return kanal;
			}
			catch(failed)
			{
				kanal=false;
			}  
		}
	}
	if(!kanal)
	{
		alert("jebiga");
	}
}
function mesec(mesec)
{
	mesec=parseInt(mesec);
	kanal=kreiranje();
	
	if(!kanal)
	{
		alert("Kanal nije napravljen");
	}
	else
	{
		kanal.onreadystatechange=pokreni;
		kanal.open('GET','mesec.php?mesec='+mesec,'true');
		kanal.send();
	}
}
function pokreni()
{

	if(kanal.ReadyState==0)
	{
		alert("0");
	}
	else if(kanal.ReadyState==1)
	{
		alert("1");
	}
	else if(kanal.ReadyState==2)
	{
		alert("2");
	}
	else if(kanal.ReadyState==3)
	{
		alert("3");
	}
	else
	{	
		
		document.getElementById("ddlDan").innerHTML=kanal.responseText;
	}

}