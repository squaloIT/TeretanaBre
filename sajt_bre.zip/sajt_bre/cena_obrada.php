﻿<?php
	if(isset($_GET['cenaOD']))
	{
		$cenaOD=$_GET['cenaOD'];
		$DOcena=$_GET['DOcena'];
		$vreme=$_GET['vreme'];
		
		if($DOcena=="0" && $vreme == "0")
		{
			include("konekcija.inc");
			$upit="SELECT * FROM vreme v JOIN cene c ON v.id_vreme= c.id_vreme JOIN termini t ON t.id_termin=c.id_koristi WHERE cene > ".$cenaOD;
			$rez=mysql_query($upit);
			echo("<table border=\"1\" width=\"100%\" >
										<tr><th>Broj termina</th><th>Vreme dolaska</th><th>Cena</th></tr>");
			while($red=mysql_fetch_array($rez))
				{
					
					if($red['id_cene']%2==0)
					{
						echo("<tr style=\"background:#3366FF;\"><td>".$red['termin']."</td><td>".$red['vreme']."</td><td>".$red['cene']."</td></tr>");
					}
					else
					{
						echo("<tr><td>".$red['termin']."</td><td>".$red['vreme']."</td><td>".$red['cene']."</td></tr>");
					}
				}
				echo("</table>");
			mysql_close();
		}
		else if($cenaOD=="0" && $DOcena=="0")
		{
			include("konekcija.inc");
			$upit="SELECT * FROM vreme v JOIN cene c ON v.id_vreme= c.id_vreme JOIN termini t ON t.id_termin=c.id_koristi WHERE v.id_vreme=".$vreme;
			$rez=mysql_query($upit);
			echo("<table border=\"1\" width=\"100%\" >
										<tr><th>Broj termina</th><th>Vreme dolaska</th><th>Cena</th></tr>");
			while($red=mysql_fetch_array($rez))
				{
					
					if($red['id_cene']%2==0)
					{
						echo("<tr style=\"background:#3366FF;\"><td>".$red['termin']."</td><td>".$red['vreme']."</td><td>".$red['cene']."</td></tr>");
					}
					else
					{
						echo("<tr><td>".$red['termin']."</td><td>".$red['vreme']."</td><td>".$red['cene']."</td></tr>");
					}
				}
				echo("</table>");
			mysql_close();
		}
		
		
		else if($cenaOD=="0" && $vreme=="0")
		{
			include("konekcija.inc");
			$upit="SELECT * FROM vreme v JOIN cene c ON v.id_vreme= c.id_vreme JOIN termini t ON t.id_termin=c.id_koristi WHERE cene < ".$DOcena;
			$rez=mysql_query($upit);
			echo("<table border=\"1\" width=\"100%\" >
										<tr><th>Broj termina</th><th>Vreme dolaska</th><th>Cena</th></tr>");
			while($red=mysql_fetch_array($rez))
				{
					
					if($red['id_cene']%2==0)
					{
						echo("<tr style=\"background:#3366FF;\"><td>".$red['termin']."</td><td>".$red['vreme']."</td><td>".$red['cene']."</td></tr>");
					}
					else
					{
						echo("<tr><td>".$red['termin']."</td><td>".$red['vreme']."</td><td>".$red['cene']."</td></tr>");
					}
				}
				echo("</table>");
			mysql_close();
		}
		
		else if($vreme=="0")
		{
			include("konekcija.inc");
			$upit="SELECT * FROM vreme v JOIN cene c ON v.id_vreme= c.id_vreme JOIN termini t ON t.id_termin=c.id_koristi WHERE cene > ".$cenaOD." AND cene < ".$DOcena;
			$rez=mysql_query($upit);
			echo("<table border=\"1\" width=\"100%\" >
										<tr><th>Broj termina</th><th>Vreme dolaska</th><th>Cena</th></tr>");
			while($red=mysql_fetch_array($rez))
				{
					
					if($red['id_cene']%2==0)
					{
						echo("<tr style=\"background:#3366FF;\"><td>".$red['termin']."</td><td>".$red['vreme']."</td><td>".$red['cene']."</td></tr>");
					}
					else
					{
						echo("<tr><td>".$red['termin']."</td><td>".$red['vreme']."</td><td>".$red['cene']."</td></tr>");
					}
				}
				echo("</table>");
			mysql_close();
			
		}
		
		else if($cenaOD=="0")
		{
			include("konekcija.inc");
			$upit="SELECT * FROM vreme v JOIN cene c ON v.id_vreme= c.id_vreme JOIN termini t ON t.id_termin=c.id_koristi WHERE cene < ".$DOcena." AND v.id_vreme=".$vreme;
			$rez=mysql_query($upit);
			echo("<table border=\"1\" width=\"100%\" >
										<tr><th>Broj termina</th><th>Vreme dolaska</th><th>Cena</th></tr>");
			while($red=mysql_fetch_array($rez))
				{
					
					if($red['id_cene']%2==0)
					{
						echo("<tr style=\"background:#3366FF;\"><td>".$red['termin']."</td><td>".$red['vreme']."</td><td>".$red['cene']."</td></tr>");
					}
					else
					{
						echo("<tr><td>".$red['termin']."</td><td>".$red['vreme']."</td><td>".$red['cene']."</td></tr>");
					}
				}
				echo("</table>");
			mysql_close();
		}
		
		else if($DOcena=="0")
		{
			
			include("konekcija.inc");
			$upit="SELECT * FROM vreme v JOIN cene c ON v.id_vreme= c.id_vreme JOIN termini t ON t.id_termin=c.id_koristi WHERE cene > ".$cenaOD." AND v.id_vreme=".$vreme;
			$rez=mysql_query($upit);
			echo("<table border=\"1\" width=\"100%\" >
										<tr><th>Broj termina</th><th>Vreme dolaska</th><th>Cena</th></tr>");
			while($red=mysql_fetch_array($rez))
				{
					
					if($red['id_cene']%2==0)
					{
						echo("<tr style=\"background:#3366FF;\"><td>".$red['termin']."</td><td>".$red['vreme']."</td><td>".$red['cene']."</td></tr>");
					}
					else
					{
						echo("<tr><td>".$red['termin']."</td><td>".$red['vreme']."</td><td>".$red['cene']."</td></tr>");
					}
				}
				echo("</table>");
			mysql_close();
		}
		
		
		
		
		
		else
		{
			include("konekcija.inc");
			$upit="SELECT * FROM vreme v JOIN cene c ON v.id_vreme= c.id_vreme JOIN termini t ON t.id_termin=c.id_koristi WHERE cene > ".$cenaOD." AND cene < ".$DOcena." AND v.id_vreme=".$vreme;
			$rez=mysql_query($upit);
			echo("<table border=\"1\" width=\"100%\" >
										<tr><th>Broj termina</th><th>Vreme dolaska</th><th>Cena</th></tr>");
			while($red=mysql_fetch_array($rez))
				{
					
					if($red['id_cene']%2==0)
					{
						echo("<tr style=\"background:#3366FF;\"><td>".$red['termin']."</td><td>".$red['vreme']."</td><td>".$red['cene']."</td></tr>");
					}
					else
					{
						echo("<tr><td>".$red['termin']."</td><td>".$red['vreme']."</td><td>".$red['cene']."</td></tr>");
					}
				}
				echo("</table>");
			mysql_close();
		}
	
	
	}
?>