﻿<? session_start(); ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" 
"http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html>
		<title>Teretana BRE | Instruktori</title>
		<meta http-equiv="Content-Type" content="text/html"; charset="UTF-8"> 
	
		<meta name="keywords" content="Bre, teretana, instruktori">
 
		<meta name="author" content="Nikola Mihajlovic"/ >
		
		<link rel="stylesheet" href="css/instruktori.css" type="text/css" />
		
		<link rel="shortcut icon" href="ikone/icon.jpg" type="image/x-icon" />
	
		<link href='http://fonts.googleapis.com/css?family=Droid+Serif' rel='stylesheet' type='text/css'/>
		<link href='http://fonts.googleapis.com/css?family=Ubuntu|Vollkorn' rel='stylesheet' type='text/css'/>
		
		<link rel="stylesheet" href="//code.jquery.com/ui/1.11.4/themes/smoothness/jquery-ui.css">
		
		<script src="//code.jquery.com/jquery-1.10.2.js"></script>
		<script src="//code.jquery.com/ui/1.11.4/jquery-ui.js"></script>
		<script type="text/javascript" src="js/treninzi_ajax.js"></script>
		<script type="text/javascript" src="js/ime_ajax.js"></script>
		
	</head>
	
	<body>
			<div id="ispis">
				<h1 id="szc" title="Naslov teretana BRE">TERETANA<a href="teretana_bre_index.php" id="bre"> &nbspBRE</a></h1>
				<p class="malo" title="Sportski zabavni centar">Sportski, zabavni i rekreativni centar</p>
					
				<?php
					include('ispis.inc');
				?>
			</div>
			<div id="meni">
					<?php
						include('meni.inc');
					?>
				</div>
			<div id="omotac">
					<div id="sredina">
					<!--  SVE OVO TREBA U BAZU PA DA SE IZVLACI -->
						<?php 
							include("konekcija.inc");
							$upit4="SELECT * FROM instruktor";
							$rez4=mysql_query($upit4);
							if($rez4 == FALSE)
							{
								die(mysql_error());
							}
							while($r=mysql_fetch_array($rez4))
							{
								echo("<div class=\"instruktor\">");
									echo("<h2 class=\"instruktor_naslov\">".$r['ime_prezime']."</h2>");
									echo("<div class=\"instruktor_ispis\">");
										echo("<p class=\"o_njemu\">".$r['o_njemu']."</br></br><b>&nbsp&nbsp&nbsp&nbsp&nbspKontakt:".$r['kontakt']."</b></p>");
									echo("</div>");
									echo("<div class=\"instruktor_slika\"><img src=".$r['slika']." alt=".$r['ime_prezime']." width=\"100%\" height=\"250px\"/></div>");
								echo("</div>");
							}
							mysql_close();
						?>
						
						
						<!--sve do oovde -->
					</div>
					<div id="desno">
				<?php
					include("instruktori_desno.inc");
				?>
					</div>
			
			
			</div>
		
		<?php
				include("footer.inc");
		?>
	</body>
</html>