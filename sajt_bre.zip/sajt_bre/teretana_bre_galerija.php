﻿<? session_start(); ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" 
"http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html>
		<title>Teretana BRE | Galerija</title>
		<meta http-equiv="Content-Type" content="text/html"; charset="UTF-8"> 
		
		<meta name="keywords" content="Bre, teretana, galerija">
		<meta name="author" content="Nikola Mihajlovic"/ >
		
		<link rel="stylesheet" href="css/galerija.css" type="text/css" />
		<link rel="shortcut icon" href="ikone/icon.jpg" type="image/x-icon" />
	
		<link href='http://fonts.googleapis.com/css?family=Droid+Serif' rel='stylesheet' type='text/css'/>
		<link href='http://fonts.googleapis.com/css?family=Ubuntu|Vollkorn' rel='stylesheet' type='text/css'/>
		
		<link rel="stylesheet" href="//code.jquery.com/ui/1.11.4/themes/smoothness/jquery-ui.css">
		
		<script src="//code.jquery.com/jquery-1.10.2.js"></script>
		<script src="//code.jquery.com/ui/1.11.4/jquery-ui.js"></script>
		
		
		
	</head>
	
	<body>
			<div id="ispis">
				<h1 id="szc" title="Naslov teretana BRE">TERETANA<a href="teretana_bre_index.php" id="bre"> &nbspBRE</a></h1>
				<p class="malo" title="Sportski zabavni centar">Sportski, zabavni i rekreativni centar</p>
					
				<?php
					include('ispis.inc');
				?>
			</div>
			
			<div id="meni">
					<?php
						include('meni.inc');
					?>
			</div>
			
		<div id="omotac">
			<div id="sredina">
					
					<?php
						include('konekcija.inc');
						$upit="SELECT * FROM galerija_slike";
						$rez=mysql_query($upit);
						while($red=mysql_fetch_array($rez))
						{
							$pera=$red['id_slike'];
							$alt=$red['naziv'];
							echo("<div class='slike'><img src=".$red['putanja']." alt=".$red['naziv']." width=\"220px\" height=\"230px\"  onClick=\"display('$pera'); \"/></div>");
						}
						
					?>
						
			</div>
			<div id="lightbox">
			
					<div class="image">
						
					</div>
					
					<div class="levo" onclick="levo()">
					</div>
					
					<div class="desno" onclick="desno()">
					</div>
					
					<div class="zatvori" onClick="zatvori()">
						<span><img src="ikone/Untitled-3.png" alt="close"></span>
					</div>
			</div>
			<div id="desno">
					<?php
						include("galerija_desno.inc");
					?>
			</div>
		</div>
		
		<?php
				include("footer.inc");
		?>
	</body>
	<script type="text/javascript">
	var mica;

	
		function display(src)
		{
			mica=src;
			$('.image').html("<img src = \"gym/Teretana_BRE_"+src+".jpg\" width=\"800px\" height=\"600px\"/>");
			$('.image').css("display","block");
			$('.desno').css("display","block");
			$('.levo').css("display","block");
			$('#lightbox').css("display","block");
			$('#lightbox').fadeIn();

		}
		function zatvori()
		{
			$('.image').css("display","none");
			$('.levo').css("display","none");
			$('.desno').css("display","none");
			$('#lightbox').css("display","none");
		}
		function desno()
		{
			mica=parseInt(mica);
			
			if(mica == 18)
			{
				mica=1;
				$('.image').html("<img src= \"gym/Teretana_BRE_"+mica+".jpg\" width=\"800px\" height=\"600px\" />");
				
			}
			else
			{
				
				mica=mica+1;
				
				$('.image').html("<img src= \"gym/Teretana_BRE_"+mica+".jpg\" width=\"800px\" height=\"600px\" />");
				
			}
		}
		function levo()
		{
			mica=parseInt(mica);
			
			if(mica == 1)
			{
				mica=18;
				$('.image').html("<img src= \"gym/Teretana_BRE_"+mica+".jpg\" width=\"800px\" height=\"600px\"/>");
				
			}
			else
			{
				mica = mica - 1;
				$('.image').html("<img src= \"gym/Teretana_BRE_"+mica+".jpg\" width=\"800px\" height=\"600px\"/>");
				
			}
		}
	</script>
</html>