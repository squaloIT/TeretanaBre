﻿<?php session_start();?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" 
"http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html>
<head>
		<title>Teretana BRE | Admin</title>
		<meta http-equiv="Content-Type" content="text/html"; charset="UTF-8"> 
		<meta name="author" content="Nikola Mihajlovic"/ >
		<link rel="stylesheet" href="css/admin.css" type="text/css" />
		<link rel="shortcut icon" href="ikone/icon.jpg" type="image/x-icon" />
	
		<link href='http://fonts.googleapis.com/css?family=Droid+Serif' rel='stylesheet' type='text/css'/>
		<link href='http://fonts.googleapis.com/css?family=Ubuntu|Vollkorn' rel='stylesheet' type='text/css'/>
		
		<link rel="stylesheet" href="//code.jquery.com/ui/1.11.4/themes/smoothness/jquery-ui.css">
		
		<script src="//code.jquery.com/jquery-1.10.2.js"></script>
		<script src="//code.jquery.com/ui/1.11.4/jquery-ui.js"></script>
	</head>	
	<body>
			<div id="ispis">
				<h1 id="szc" title="Naslov teretana BRE">RODJENDAONICA<a href="teretana_bre_index.php" id="bre"> &nbspBRE</a></h1>
				<p class="malo" title="Sportski zabavni centar">Zabavni, drustveni i rekreativni centar</p>
					
				<?php
					include('ispis.inc');
				?>
			</div>
			<div id="meni">
					<?php
						include('meni_rodj.inc');
					?>
				</div>
		<div id="omotac">
			<div id="sredina">
			<?php 
			if(isset($_REQUEST['btnProvera']))
			{
				include("konekcija.inc");
				$user=$_POST['tbUser'];
				$pass=$_POST['tbPass'];
				$user=addslashes($user);
				$pass=addslashes($pass);
				$zapit="SELECT * FROM admin WHERE username='$user' AND password='$pass'";
				$rez_query=mysql_query($zapit) or die();
				
				$pocepati=mysql_fetch_array($rez_query) or die(mysql_error());
			
				if(empty($pocepati))
				{
					echo("Pokusajte opet sa ukucavanjem lozinke");
				}
				else
				
				{
					$_SESSION['admin']="admin";
					include("konekcija.inc");
					$query2="select * from instruktor";
					$rezultat=mysql_query($query2, $konekcija) or die(mysql_error());
					echo("<table border=\"1px\">");
					
					echo("<form action='obrisi_vise_instruktor.php' mehod=\"post\">");
					
					echo("<tr><th>id</th><th>ime prezime</th><th>slika putanja</th><th>kontakt</th><th>dodaj</th><th>izmeni</th><th>obrisi</th><th>obrisi vise</th></tr>");
					while($redic=mysql_fetch_assoc ($rezultat) )
					{
						echo("<tr><td>".$redic['id_instruktora']."</td><td>".$redic['ime_prezime']."</td><td>".$redic['slika']."</td><td>".$redic['kontakt']."</td><td></td>
						<td><a href='izmeni.php?id_instruktora=".$redic['id_instruktora']."'>izmeni</a></td><td><a href='obrisi.php?id_instruktora=".$redic['id_instruktora']."'>obrisi</a></td>
						<td><input type='checkbox' name='chbobrisi[]' id='chbobrisi' value='".$redic['id_instruktora']."'/></td></tr>");
					}
					
					echo("<tr><td></td><td></td><td></td><td></td><td><a href='dodaj_instruktora.php'>dodaj</a><td></td></td><td></td><td><input type=\"submit\" name=\"btnobrisi\" id=\"btnobrisi\" value=\"obrisi cekirano\"/></td></tr>");
					echo("</form>");
					echo("</table></br></br>");
					
					
					$query3="select * from zakazivanje";
					$rezultat2=mysql_query($query3, $konekcija) or die(mysql_error());
					echo("<table border=\"1px\">");
					
					echo("<form action='obrisi_vise_zakazivanje.php' mehod=\"post\">");
					
					echo("<tr><th>id</th><th>ime</th><th> prezime</th><th>kontakt</th><th>email</th><th>godina</th><th>mesec</th><th>dan</th><th>obrisi</th><th>obrisi vise</th></tr>");
					while($redic2=mysql_fetch_assoc ($rezultat2) )
					{
						echo("<tr><td>".$redic2['id_zakazivanja']."</td><td>".$redic2['ime']."</td><td>".$redic2['prezime']."</td><td>".$redic2['telefon']."</td>
						<td>".$redic2['email']."</td><td>".$redic2['godina']."</td><td>".$redic2['mesec']."</td><td>".$redic2['dan']."</td>
						<td><a href='obrisi.php?id_zakazivanja=".$redic2['id_zakazivanja']."'>obrisi</a></td>
						<td><input type='checkbox' name='chbobrisi[]' id='chbobrisi' value='".$redic2['id_zakazivanja']."'/></td></tr>");
					}
					
					echo("<tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td><input type=\"submit\" name=\"btnobrisi\" id=\"btnobrisi\" value=\"obrisi cekirano\"/></td></tr>");
					echo("</form>");
					echo("</table></br></br>");
					
					
					$query4="select * from galerija_slike";
					$rezultat3=mysql_query($query4, $konekcija) or die(mysql_error());
					echo("<table border=\"1px\">");
					
					echo("<form action='obrisi_vise_galerija_bre.php' mehod=\"post\">");
					
					echo("<tr><th>id</th><th>naziv</th><th>putanja</th><th>dodaj</th><th>obrisi</th><th>obrisi vise</th></tr>");
					while($redic3=mysql_fetch_assoc ($rezultat3) )
					{
						echo("<tr><td>".$redic3['id_slike']."</td><td>".$redic3['naziv']."</td><td>".$redic3['putanja']."</td>
						
						<td></td><td><a href='obrisi.php?id_slike=".$redic3['id_slike']."'>obrisi</a></td>
						<td><input type='checkbox' name='chbobrisi[]' id='chbobrisi' value='".$redic3['id_slike']."'/></td></tr>");
					}
					
					echo("<tr><td></td><td></td><td></td><td><a href='dodaj_sliku_bre.php'>dodaj</a></td><td></td><td><input type=\"submit\" name=\"btnobrisi\" id=\"btnobrisi\" value=\"obrisi cekirano\"/></td></tr>");
					echo("</form>");
					echo("</table></br></br>");
					
					
					$query4="select * from rodj_galerija";
					$rezultat3=mysql_query($query4, $konekcija) or die(mysql_error());
					echo("<table border=\"1px\">");
					
					echo("<form action='obrisi_vise_galerija_rodj.php' mehod=\"post\">");
					
					echo("<tr><th>id</th><th>putanja</th><th>naziv</th><th>dodaj</th><th>obrisi</th><th>obrisi vise</th></tr>");
					while($redic3=mysql_fetch_assoc ($rezultat3) )
					{
						echo("<tr><td>".$redic3['id_slike']."</td><td>".$redic3['putanja']."</td><td>".$redic3['naziv']."</td>
						
						<td></td><td><a href='obrisi.php?id_rodj_slike=".$redic3['id_slike']."'>obrisi</a></td>
						<td><input type='checkbox' name='chbobrisi[]' id='chbobrisi' value='".$redic3['id_slike']."'/></td></tr>");
					}
					
					echo("<tr><td></td><td></td><td></td><td><a href='dodaj_sliku_rodj.php'>dodaj</a></td><td></td><td><input type=\"submit\" name=\"btnobrisi\" id=\"btnobrisi\" value=\"obrisi cekirano\"/></td></tr>");
					echo("</form>");
					echo("</table></br></br>");
				}
			}
			else
			{
				if(isset($_SESSION['admin']))
				{
						include("konekcija.inc");
					$query2="select * from instruktor";
					$rezultat=mysql_query($query2, $konekcija) or die(mysql_error());
					echo("<table border=\"1px\">");
					
					echo("<form action='obrisi_vise_instruktor.php' mehod=\"post\">");
					
					echo("<tr><th>id</th><th>ime prezime</th><th>slika putanja</th><th>kontakt</th><th>dodaj</th><th>izmeni</th><th>obrisi</th><th>obrisi vise</th></tr>");
					while($redic=mysql_fetch_assoc ($rezultat) )
					{
						echo("<tr><td>".$redic['id_instruktora']."</td><td>".$redic['ime_prezime']."</td><td>".$redic['slika']."</td><td>".$redic['kontakt']."</td><td></td>
						<td><a href='izmeni.php?id=".$redic['id_instruktora']."'>izmeni</a></td><td><a href='obrisi.php?id_instruktora=".$redic['id_instruktora']."'>obrisi</a></td>
						<td><input type='checkbox' name='chbobrisi[]' id='chbobrisi' value='".$redic['id_instruktora']."'/></td></tr>");
					}
					
					echo("<tr><td></td><td></td><td></td><td></td><td><a href='dodaj_instruktora.php'>dodaj</a><td></td></td><td></td><td><input type=\"submit\" name=\"btnobrisi\" id=\"btnobrisi\" value=\"obrisi cekirano\"/></td></tr>");
					echo("</form>");
					echo("</table></br></br>");
					
					
					$query3="select * from zakazivanje";
					$rezultat2=mysql_query($query3, $konekcija) or die(mysql_error());
					echo("<table border=\"1px\">");
					
					echo("<form action='obrisi_vise_zakazivanje.php' mehod=\"post\">");
					
					echo("<tr><th>id</th><th>ime</th><th> prezime</th><th>kontakt</th><th>email</th><th>godina</th><th>mesec</th><th>dan</th><th>izmeni</th><th>obrisi</th><th>obrisi vise</th></tr>");
					while($redic2=mysql_fetch_assoc ($rezultat2) )
					{
						echo("<tr><td>".$redic2['id_zakazivanja']."</td><td>".$redic2['ime']."</td><td>".$redic2['prezime']."</td><td>".$redic2['telefon']."</td>
						<td>".$redic2['email']."</td><td>".$redic2['godina']."</td><td>".$redic2['mesec']."</td><td>".$redic2['dan']."</td>
						<td><a href='izmeni.php?id=".$redic2['id_zakazivanja']."'>izmeni</a></td><td><a href='obrisi.php?id_zakazivanja=".$redic2['id_zakazivanja']."'>obrisi</a></td>
						<td><input type='checkbox' name='chbobrisi[]' id='chbobrisi' value='".$redic2['id_zakazivanja']."'/></td></tr>");
					}
					
					echo("<tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td><input type=\"submit\" name=\"btnobrisi\" id=\"btnobrisi\" value=\"obrisi cekirano\"/></td></tr>");
					echo("</form>");
					echo("</table></br></br>");
					
					
					$query4="select * from galerija_slike";
					$rezultat3=mysql_query($query4, $konekcija) or die(mysql_error());
					echo("<table border=\"1px\">");
					
					echo("<form action='obrisi_vise_galerija_bre.php' mehod=\"post\">");
					
					echo("<tr><th>id</th><th>naziv</th><th>putanja</th><th>dodaj</th><th>obrisi</th><th>obrisi vise</th></tr>");
					while($redic3=mysql_fetch_assoc ($rezultat3) )
					{
						echo("<tr><td>".$redic3['id_slike']."</td><td>".$redic3['naziv']."</td><td>".$redic3['putanja']."</td>
						
						<td></td><td><a href='obrisi.php?id_slike=".$redic3['id_slike']."'>obrisi</a></td>
						<td><input type='checkbox' name='chbobrisi[]' id='chbobrisi' value='".$redic3['id_slike']."'/></td></tr>");
					}
					
					echo("<tr><td></td><td></td><td></td><td><a href='dodaj_sliku_bre.php'>dodaj</a></td><td></td><td><input type=\"submit\" name=\"btnobrisi\" id=\"btnobrisi\" value=\"obrisi cekirano\"/></td></tr>");
					echo("</form>");
					echo("</table></br></br>");
					
					
					$query4="select * from rodj_galerija";
					$rezultat3=mysql_query($query4, $konekcija) or die(mysql_error());
					echo("<table border=\"1px\">");
					
					echo("<form action='obrisi_vise_galerija_rodj.php' mehod=\"post\">");
					
					echo("<tr><th>id</th><th>putanja</th><th>naziv</th><th>dodaj</th><th>obrisi</th><th>obrisi vise</th></tr>");
					while($redic3=mysql_fetch_assoc ($rezultat3) )
					{
						echo("<tr><td>".$redic3['id_slike']."</td><td>".$redic3['putanja']."</td><td>".$redic3['naziv']."</td>
						
						<td></td><td><a href='obrisi.php?id_rodj_slike=".$redic3['id_slike']."'>obrisi</a></td>
						<td><input type='checkbox' name='chbobrisi[]' id='chbobrisi' value='".$redic3['id_slike']."'/></td></tr>");
					}
					
					echo("<tr><td></td><td></td><td></td><td><a href='dodaj_sliku_rodj.php'>dodaj</a></td><td></td><td><input type=\"submit\" name=\"btnobrisi\" id=\"btnobrisi\" value=\"obrisi cekirano\"/></td></tr>");
					echo("</form>");
					echo("</table></br></br>");
				}
				
				else
				{
					echo("<form method=\"POST\" action=\"admin.php\">");
					echo("<h2 class=\"ispisati\">Username</h2></br>");
					echo("<input type=\"text\" name=\"tbUser\" id=\"tbUser\" class=\"tb\"/></br>");
					echo("<h2 class=\"ispisati\">Password</h2></br>");
					echo("<input type=\"password\" name=\"tbPass\" id=\"tbPass\" class=\"tb\"/></br>");
					echo("<input type=\"submit\" name=\"btnProvera\" id=\"btnProvera\" value=\"Log In\"/></br>");
					
					echo("</form>");
				}
			}

		?>
				
				
			</div>
			
			<div id="desno">
					<?php
						include("desno_rodj.inc");
					?>
			</div>
			
		</div>
		
		<?php
				include("footer.inc");
		?>
	</body>
</html>