﻿<?php
if(isset($_REQUEST['btnobrisi']))
{
	
	$chb=$_REQUEST['chbobrisi'];
	
	include("konekcija.inc");
		foreach($chb AS $c)
		{
			$upit="DELETE FROM rodj_galerija WHERE id_slike=".$c;
			mysql_query($upit);
			echo($c);
		}
		mysql_close();
		header("location:admin.php");
	}
?>