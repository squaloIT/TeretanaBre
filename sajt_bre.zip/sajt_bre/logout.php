﻿<?php session_start(); ?>
<?php
	unset($_SESSION['admin']);
	session_destroy();
	header("location:teretana_bre_index.php");
?>