﻿<? session_start(); ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" 
"http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html>
<head>
		<title>Teretana BRE | Cene</title>
		<meta http-equiv="Content-Type" content="text/html"; charset="UTF-8"> 
		<meta name="keywords" content="Bre, teretana, gym, fitness, rodjendaonica, caffe, rodjendan, kafic, kardio, ninas, trening, oprema">
		<meta name="author" content="Nikola Mihajlovic"/ >
		
		<link rel="stylesheet" href="css/cene.css" type="text/css" />
		
		<link rel="shortcut icon" href="ikone/icon.jpg" type="image/x-icon" />
	
		<link href='http://fonts.googleapis.com/css?family=Droid+Serif' rel='stylesheet' type='text/css'/>
		<link href='http://fonts.googleapis.com/css?family=Ubuntu|Vollkorn' rel='stylesheet' type='text/css'/>
		
		<link rel="stylesheet" href="//code.jquery.com/ui/1.11.4/themes/smoothness/jquery-ui.css">
		
		<script src="//code.jquery.com/jquery-1.10.2.js"></script>
		<script src="//code.jquery.com/ui/1.11.4/jquery-ui.js"></script>
		<script type="text/javascript" src="js/cene_ajax.js"></script>

		
	</head>
	
	<body>
			<div id="ispis">
				<h1 id="szc" title="Naslov teretana BRE">TERETANA<a href="teretana_bre_index.php" id="bre"> &nbspBRE</a></h1>
				<p class="malo" title="Sportski zabavni centar">Sportski, zabavni i rekreativni centar</p>
					
				<?php
					include('ispis.inc');
				?>
			</div>
			<div id="meni">
					<?php
						include('meni.inc');
					?>
				</div>
			<div id="omotac">
					<div id="sredina">
					<!--  SVE OVO TREBA U BAZU PA DA SE IZVLACI -->
						<h1 class="naslov"><b>Cene paketa Teretane BRE!</b></h1>
							
							<p class="sredina_paragraf">Приликом коришћења основних пакета можете вежбати сами, уз инструкције инструктора у смени или уз
								константан надзор персоналног инструктора.</br></br>

								<b>Учлањење у клуб износи 200 дин. </b>
								Није могуће учланити се у клуб без личне карте или другог документа са сликом.
							</p>
							<div id="tabela">
									<table border="1" width="100%" >
										
										<?php
										$koliko=5;
										if(isset($_GET['skriveno']))
										{
											$skriveno=$_GET['skriveno'];
										}
										else
										{
											$skriveno=0;
										}
											include("konekcija.inc");
											$upit_broj=mysql_query("SELECT COUNT(id_cene) FROM cene") or die(mysql_error());
											$niz=mysql_fetch_array($upit_broj) or die(mysql_error());
											
											$ukupno=$niz[0];
											$levo=$skriveno-$koliko;
											$desno=$skriveno+$koliko;
											
											if($levo<0)
											{
												echo"<tr><th>Pocetak</th><th>Broj termina</th><th>Vreme dolaska</th><th>Cena</th><th><a href=\"teretana_bre_cene.php?skriveno=".$desno."\">Napred</a></th></tr>";
											}
											else if($desno>$ukupno)
											{
												echo"<tr><th><a href=\"teretana_bre_cene.php?skriveno=".$levo."\">Nazad</a></th><th>Broj termina</th><th>Vreme dolaska</th><th>Cena</th><th>Kraj</th></tr>";
											}
											else
											{
												echo"<tr><th><a href=\"teretana_bre_cene.php?skriveno=".$levo."\">Nazad</a></th><th>Broj termina</th><th>Vreme dolaska</th><th>Cena</th><th><a href=\"teretana_bre_cene.php?skriveno=".$desno."\">Napred</a></th></tr>";
											}
											$upit="SELECT * FROM vreme v JOIN cene c ON v.id_vreme= c.id_vreme JOIN termini t ON t.id_termin=c.id_koristi LIMIT ".$koliko." OFFSET ".$skriveno;
											$rez=mysql_query($upit) or die(mysql_error());
											
											while($red=mysql_fetch_array($rez))
											{
												if($red['id_cene']%2==0)
												{
													echo("<tr style=\"background:#3366FF;\"><td></td><td>".$red['termin']."</td><td>".$red['vreme']."</td><td>".$red['cene']."</td></tr>");
												}
													else
													{
														echo("<tr><td></td><td>".$red['termin']."</td><td>".$red['vreme']."</td><td>".$red['cene']."</td></tr>");
													}
											}
											mysql_close();
										?>
									</table>
							</div>
						<div id="slika">
							<img src="gym/paketi_01.jpg" alt="paketi i cene" width="100%" height="400px"/>
						</div>
					</div>
					<div id="desno">
				<?php
					include("cene_desno.inc");
				?>
					</div>
			
			
			</div>
		
		<?php
				include("footer.inc");
		?>
	</body>
</html>