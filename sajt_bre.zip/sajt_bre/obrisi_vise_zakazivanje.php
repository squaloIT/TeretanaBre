﻿<?php
if(isset($_REQUEST['btnobrisi']))
{
	
	$chb=$_REQUEST['chbobrisi'];
	
	include("konekcija.inc");
		foreach($chb AS $c)
		{
			$upit="DELETE FROM zakazivanje WHERE id_zakazivanja=".$c;
			mysql_query($upit);
			echo($c);
		}
		mysql_close();
		header("location:admin.php");
		
	}
?>