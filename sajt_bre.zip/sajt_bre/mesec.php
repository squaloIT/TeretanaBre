﻿<?php
	if(isset($_GET['mesec']))
	{
		$mesec=$_GET['mesec'];
		if($mesec==2)
		{
			echo("<option value=\"0\">Dan</option>");
			for($i=1;$i<29; $i++)
			{
				echo("<option value=".$i.">".$i."</option>");
			}
		}
		else if($mesec%2==1)
		{
			echo("<option value=\"0\">Dan</option>");
			for($i=1;$i<32; $i++)
			{
				echo("<option value=".$i.">".$i."</option>");
			}
		}
		else
		{
			echo("<option value=\"0\">Dan</option>");
			for($i=1;$i<31; $i++)
			{
				echo("<option value=".$i.">".$i."</option>");
			}
		}
	}
?>