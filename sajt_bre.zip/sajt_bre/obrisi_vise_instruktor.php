﻿<?php
if(isset($_REQUEST['btnobrisi']))
{
	
	$chb=$_REQUEST['chbobrisi'];
	
	include("konekcija.inc");
		foreach($chb AS $c)
		{
			$upit="DELETE FROM instruktor WHERE id_instruktora=".$c;
			mysql_query($upit);
			
		}
		mysql_close();
		header("location:admin.php");
	}
?>